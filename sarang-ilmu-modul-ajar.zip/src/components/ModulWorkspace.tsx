import { useEffect, useMemo, useState } from "react";
import { BookOpen, Copy, FileText, LogOut, Plus, Search, Trash2 } from "lucide-react";
import { Brand } from "./Brand";
import { ModulBuilderForm } from "./ModulBuilderForm";
import { ModulDocumentView } from "./ModulDocumentView";
import { PanduanPmView } from "./PanduanPmView";
import { AdminTeachersView } from "./AdminTeachersView";
import { KaldikOtomatisView } from "./KaldikOtomatisView";
import { ProtaProsemView } from "./ProtaProsemView";
import { CoverPerangkatView } from "./CoverPerangkatView";
import { PresensiNilaiView } from "./PresensiNilaiView";
import type { Jenjang, ModulAjar, TeacherUser } from "../types/modul";
import type {
  AcademicClass,
  AkademikSignatureMeta,
  AkademikWorkspaceData,
  AttendanceMap,
  CoverPerangkatConfig,
  GradeSheetMap,
  HariSekolahMode,
  KaldikDayNote,
  ProsemDocument,
  ProtaDocument,
} from "../types/akademik";
import {
  buildKaldikYear,
  createDefaultCoverConfig,
  createStarterClasses,
} from "../lib/akademikEngine";

interface ModulWorkspaceProps {
  user: TeacherUser;
  token: string;
  onLogout: () => void;
}

type WorkspaceTab = "library" | "builder" | "kurikulum" | "penilaian" | "guide" | "admin";
type KurikulumSubTab = "kaldik" | "prota-prosem" | "cover";

function buildInitialAkademikData(user: TeacherUser): AkademikWorkspaceData {
  const starterClasses = createStarterClasses();
  const tahunAjaran = "2026/2027";
  return {
    tahunAjaran,
    hariSekolah: 5,
    kktpMinimal: 71,
    bobotFormatif: 40,
    meta: {
      sekolah: user.school || "Satuan Pendidikan Indonesia",
      penyusun: user.name || "Guru Mata Pelajaran",
      nipGuru: "",
      namaKepalaSekolah: "",
      nipKepalaSekolah: "",
      kotaTanggal: `Indonesia, ${new Date().getFullYear()}`,
    },
    coverConfig: createDefaultCoverConfig({
      sekolah: user.school || "Satuan Pendidikan Indonesia",
      namaGuru: user.name || "Guru Mata Pelajaran",
      tahunAjaran,
    }),
    classes: starterClasses,
    selectedClassId: starterClasses[0].id,
    kaldikOverrides: {},
    protaRecords: {},
    prosemRecords: {},
    presensiRecords: {},
    nilaiRecords: {},
  };
}

function mergeAkademikData(
  raw: Partial<AkademikWorkspaceData> | null | undefined,
  user: TeacherUser
): AkademikWorkspaceData {
  const base = buildInitialAkademikData(user);
  if (!raw || typeof raw !== "object") return base;
  const classes =
    Array.isArray(raw.classes) && raw.classes.length > 0 ? raw.classes : base.classes;
  return {
    ...base,
    ...raw,
    meta: { ...base.meta, ...(raw.meta ?? {}) },
    coverConfig: { ...base.coverConfig, ...(raw.coverConfig ?? {}) },
    classes,
    selectedClassId:
      raw.selectedClassId && classes.some((c) => c.id === raw.selectedClassId)
        ? raw.selectedClassId
        : classes[0].id,
    kaldikOverrides: raw.kaldikOverrides ?? {},
    protaRecords: raw.protaRecords ?? {},
    prosemRecords: raw.prosemRecords ?? {},
    presensiRecords: raw.presensiRecords ?? {},
    nilaiRecords: raw.nilaiRecords ?? {},
  };
}

export function ModulWorkspace({ user, token, onLogout }: ModulWorkspaceProps) {
  const [tab, setTab] = useState<WorkspaceTab>("library");
  const [kurikulumSubTab, setKurikulumSubTab] = useState<KurikulumSubTab>("kaldik");
  const [modules, setModules] = useState<ModulAjar[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [lampiranSelectionMap, setLampiranSelectionMap] = useState<Record<string, number[]>>({});
  const [search, setSearch] = useState("");
  const [jenjangFilter, setJenjangFilter] = useState<"Semua" | Jenjang>("Semua");

  // Shared Akademik Workspace State (Kaldik, Prota, Prosem, Cover, Presensi, Nilai)
  const [akademikData, setAkademikData] = useState<AkademikWorkspaceData>(() =>
    buildInitialAkademikData(user)
  );
  const [savingAkademik, setSavingAkademik] = useState(false);
  const [akademikNotice, setAkademikNotice] = useState<string | null>(null);

  const isAdmin = user.role === "admin";

  // Obeys Top Bar Contract: max 5 single-line nav items
  const navItems: { id: WorkspaceTab; label: string }[] = isAdmin
    ? [
        { id: "library", label: "Daftar Modul" },
        { id: "builder", label: "Buat Modul" },
        { id: "kurikulum", label: "Prota & Kaldik" },
        { id: "penilaian", label: "Presensi & Nilai" },
        { id: "admin", label: "Kelola Guru" },
      ]
    : [
        { id: "library", label: "Daftar Modul" },
        { id: "builder", label: "Buat Modul" },
        { id: "kurikulum", label: "Prota & Kaldik" },
        { id: "penilaian", label: "Presensi & Nilai" },
        { id: "guide", label: "Panduan PM" },
      ];

  async function fetchModules() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/modules", {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Gagal memuat daftar modul.");
      } else {
        setModules(data.modules || []);
      }
    } catch {
      setError("Gagal terhubung ke server untuk memuat arsip modul.");
    } finally {
      setLoading(false);
    }
  }

  async function fetchAkademik() {
    try {
      const res = await fetch("/api/akademik", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) return;
      const json = await res.json();
      setAkademikData(mergeAkademikData(json.data, user));
    } catch {
      // Keep local starter akademik data cleanly
    }
  }

  useEffect(() => {
    fetchModules();
    fetchAkademik();
  }, [token]);

  async function handleSaveAkademik() {
    setSavingAkademik(true);
    setAkademikNotice(null);
    try {
      const res = await fetch("/api/akademik", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ data: akademikData }),
      });
      if (res.ok) {
        setAkademikNotice("Perangkat akademik berhasil disimpan ke server.");
        window.setTimeout(() => setAkademikNotice(null), 3500);
      } else {
        const err = await res.json().catch(() => ({}));
        setAkademikNotice(err.error || "Gagal menyimpan data perangkat akademik.");
      }
    } catch {
      setAkademikNotice("Tidak dapat terhubung ke server saat menyimpan.");
    } finally {
      setSavingAkademik(false);
    }
  }

  const kaldik = useMemo(
    () =>
      buildKaldikYear(
        akademikData.tahunAjaran,
        akademikData.hariSekolah,
        akademikData.kaldikOverrides[akademikData.tahunAjaran] ?? {}
      ),
    [akademikData.tahunAjaran, akademikData.hariSekolah, akademikData.kaldikOverrides]
  );

  const selectedModul = modules.find((m) => m.id === selectedId) ?? null;

  const filteredModules = modules.filter((m) => {
    const matchesJenjang = jenjangFilter === "Semua" || m.identitas.jenjang === jenjangFilter;
    const q = search.trim().toLowerCase();
    const matchesQuery =
      !q ||
      m.identitas.judulModul.toLowerCase().includes(q) ||
      m.identitas.mataPelajaran.toLowerCase().includes(q) ||
      m.identitas.topik.toLowerCase().includes(q);
    return matchesJenjang && matchesQuery;
  });

  async function handleSaveEdit(updated: ModulAjar) {
    const res = await fetch(`/api/modules/${encodeURIComponent(updated.id)}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ modul: updated }),
    });
    const data = await res.json();
    if (res.ok && data.modul) {
      setModules((prev) => prev.map((m) => (m.id === data.modul.id ? data.modul : m)));
    }
  }

  async function handleDuplicate(modul: ModulAjar) {
    const copyPayload: Omit<ModulAjar, "id" | "createdAt" | "updatedAt"> = {
      ...modul,
      ownerId: user.id,
      identitas: {
        ...modul.identitas,
        judulModul: `${modul.identitas.judulModul} (Salinan)`,
        penyusun: user.name,
        sekolah: user.school,
      },
    };
    const res = await fetch("/api/modules", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ modul: copyPayload }),
    });
    const data = await res.json();
    if (res.ok && data.modul) {
      setModules((prev) => [data.modul, ...prev]);
    }
  }

  async function handleDelete(id: string) {
    const res = await fetch(`/api/modules/${encodeURIComponent(id)}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${token}` },
    });
    if (res.ok) {
      setModules((prev) => prev.filter((m) => m.id !== id));
      if (selectedId === id) setSelectedId(null);
    }
  }

  function handleChangeTahunAjaran(tahun: string) {
    setAkademikData((prev) => ({
      ...prev,
      tahunAjaran: tahun,
      coverConfig: { ...prev.coverConfig, tahunAjaran: tahun },
    }));
  }

  function handleChangeHariSekolah(mode: HariSekolahMode) {
    setAkademikData((prev) => ({ ...prev, hariSekolah: mode }));
  }

  function handleUpdateDayOverride(dateStr: string, note: KaldikDayNote | null) {
    setAkademikData((prev) => {
      const yearMap = { ...(prev.kaldikOverrides[prev.tahunAjaran] ?? {}) };
      if (note === null) {
        delete yearMap[dateStr];
      } else {
        yearMap[dateStr] = note;
      }
      return {
        ...prev,
        kaldikOverrides: {
          ...prev.kaldikOverrides,
          [prev.tahunAjaran]: yearMap,
        },
      };
    });
  }

  function handleResetYearOverrides() {
    setAkademikData((prev) => {
      const next = { ...prev.kaldikOverrides };
      delete next[prev.tahunAjaran];
      return { ...prev, kaldikOverrides: next };
    });
  }

  function handleUpdateMeta(meta: AkademikSignatureMeta) {
    setAkademikData((prev) => ({ ...prev, meta }));
  }

  function handleUpdateCover(cover: CoverPerangkatConfig) {
    setAkademikData((prev) => ({ ...prev, coverConfig: cover }));
  }

  function handleSaveProta(key: string, doc: ProtaDocument) {
    setAkademikData((prev) => ({
      ...prev,
      protaRecords: { ...prev.protaRecords, [key]: doc },
    }));
  }

  function handleSaveProsem(key: string, doc: ProsemDocument) {
    setAkademikData((prev) => ({
      ...prev,
      prosemRecords: { ...prev.prosemRecords, [key]: doc },
    }));
  }

  function handleUpdateClasses(classes: AcademicClass[], selectedClassId: string) {
    setAkademikData((prev) => ({ ...prev, classes, selectedClassId }));
  }

  function handleUpdatePresensi(key: string, map: AttendanceMap) {
    setAkademikData((prev) => ({
      ...prev,
      presensiRecords: { ...prev.presensiRecords, [key]: map },
    }));
  }

  function handleUpdateNilai(key: string, map: GradeSheetMap) {
    setAkademikData((prev) => ({
      ...prev,
      nilaiRecords: { ...prev.nilaiRecords, [key]: map },
    }));
  }

  function handleUpdateNilaiSettings(kktpMinimal: number, bobotFormatif: number) {
    setAkademikData((prev) => ({ ...prev, kktpMinimal, bobotFormatif }));
  }

  return (
    <div className="min-h-screen bg-canvas">
      {/* 3-Zone Top Bar */}
      <header className="no-print sticky top-0 z-20 border-b border-border bg-card/95 backdrop-blur-xs">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-8 px-6 py-3.5">
          <button
            type="button"
            onClick={() => {
              setSelectedId(null);
              setTab("library");
            }}
            className="text-left cursor-pointer"
          >
            <Brand compact />
          </button>

          <nav className="hidden items-center gap-6 md:flex">
            {navItems.map((item) => {
              const active = !selectedModul && tab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setSelectedId(null);
                    setTab(item.id);
                  }}
                  className={`border-b-2 py-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                    active
                      ? "border-primary text-ink"
                      : "border-transparent text-muted-foreground hover:text-ink"
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-4 shrink-0">
            <span className="hidden max-w-[180px] truncate text-xs font-medium text-muted-foreground sm:inline">
              {user.name}
            </span>
            <button
              type="button"
              onClick={onLogout}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-1.5 text-xs font-semibold text-ink transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <LogOut className="size-3.5" />
              <span>Keluar</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-8">
        {/* Mobile navigation row */}
        {!selectedModul && (
          <div className="no-print mb-6 flex items-center gap-1 overflow-x-auto rounded-lg bg-slate-100 p-1 md:hidden">
            {navItems.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`flex-1 rounded-md px-2.5 py-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  tab === item.id ? "bg-card text-ink shadow-xs" : "text-muted-foreground"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        )}

        {akademikNotice && !selectedModul && (tab === "kurikulum" || tab === "penilaian") && (
          <div className="no-print mb-4 rounded-lg border border-primary/30 bg-emerald-50 px-4 py-2.5 text-xs font-semibold text-primary">
            {akademikNotice}
          </div>
        )}

        {selectedModul ? (
          <ModulDocumentView
            key={selectedModul.id}
            modul={selectedModul}
            initialIncludedLampiran={lampiranSelectionMap[selectedModul.id]}
            onBack={() => setSelectedId(null)}
            onSaveEdit={handleSaveEdit}
          />
        ) : tab === "builder" ? (
          <ModulBuilderForm
            user={user}
            token={token}
            onGenerated={(newModul, includedLampiran) => {
              setLampiranSelectionMap((prev) => ({
                ...prev,
                [newModul.id]: includedLampiran,
              }));
              setModules((prev) => [newModul, ...prev]);
              setSelectedId(newModul.id);
              setTab("library");
            }}
            onCancel={() => setTab("library")}
          />
        ) : tab === "kurikulum" ? (
          <div className="space-y-5">
            {/* Segmented Sub-navigation for Kaldik, Prota/Prosem & Cover */}
            <div className="no-print flex flex-wrap items-center justify-between gap-3">
              <div>
                <h1 className="font-display text-2xl font-semibold text-ink">
                  Perangkat Kurikulum & Penjilidan
                </h1>
                <p className="text-xs text-muted-foreground">
                  Kalender Pendidikan multi-tahun, Prota & Prosem otomatis, serta desain Cover Perangkat Ajar.
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
                {(
                  [
                    { id: "kaldik", label: "Kaldik Otomatis" },
                    { id: "prota-prosem", label: "Prota & Prosem" },
                    { id: "cover", label: "Cover Perangkat" },
                  ] as const
                ).map((sub) => (
                  <button
                    key={sub.id}
                    type="button"
                    onClick={() => setKurikulumSubTab(sub.id)}
                    className={`rounded-md px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                      kurikulumSubTab === sub.id
                        ? "bg-card text-ink shadow-xs"
                        : "text-muted-foreground hover:text-ink"
                    }`}
                  >
                    {sub.label}
                  </button>
                ))}
              </div>
            </div>

            {kurikulumSubTab === "kaldik" ? (
              <KaldikOtomatisView
                workspace={akademikData}
                kaldik={kaldik}
                onChangeTahunAjaran={handleChangeTahunAjaran}
                onChangeHariSekolah={handleChangeHariSekolah}
                onUpdateDayOverride={handleUpdateDayOverride}
                onResetYearOverrides={handleResetYearOverrides}
                onUpdateMeta={handleUpdateMeta}
                onSaveWorkspace={handleSaveAkademik}
                saving={savingAkademik}
              />
            ) : kurikulumSubTab === "prota-prosem" ? (
              <ProtaProsemView
                workspace={akademikData}
                kaldik={kaldik}
                onChangeTahunAjaran={handleChangeTahunAjaran}
                onSaveProta={handleSaveProta}
                onSaveProsem={handleSaveProsem}
                onUpdateMeta={handleUpdateMeta}
                onSaveWorkspace={handleSaveAkademik}
                saving={savingAkademik}
              />
            ) : (
              <CoverPerangkatView
                workspace={akademikData}
                onUpdateCover={handleUpdateCover}
                onSaveWorkspace={handleSaveAkademik}
                saving={savingAkademik}
              />
            )}
          </div>
        ) : tab === "penilaian" ? (
          <div className="space-y-5">
            <div className="no-print">
              <h1 className="font-display text-2xl font-semibold text-ink">
                Daftar Hadir & Rekap Nilai Otomatis
              </h1>
              <p className="text-xs text-muted-foreground">
                Presensi bulanan sinkron Kaldik, manajemen kelas/rombel, dan rekap nilai Kurikulum Merdeka berbasis KKTP.
              </p>
            </div>
            <PresensiNilaiView
              workspace={akademikData}
              onChangeTahunAjaran={handleChangeTahunAjaran}
              onUpdateClasses={handleUpdateClasses}
              onUpdatePresensi={handleUpdatePresensi}
              onUpdateNilai={handleUpdateNilai}
              onUpdateNilaiSettings={handleUpdateNilaiSettings}
              onUpdateMeta={handleUpdateMeta}
              onSaveWorkspace={handleSaveAkademik}
              saving={savingAkademik}
            />
          </div>
        ) : tab === "guide" ? (
          <PanduanPmView onStartBuilder={() => setTab("builder")} />
        ) : tab === "admin" && isAdmin ? (
          <AdminTeachersView token={token} currentUser={user} />
        ) : (
          <div className="space-y-6">
            {/* Workspace Header */}
            <div className="flex flex-wrap items-end justify-between gap-4">
              <div>
                <h1 className="font-display text-3xl font-semibold text-ink">
                  Arsip Modul Ajar & LKPD
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  {user.school} ·{" "}
                  <span className="font-mono tabular-nums">{modules.length}</span> perangkat ajar tersedia · Tanpa batas pemakaian
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => setTab("guide")}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-card px-3.5 py-2.5 text-xs font-semibold text-ink transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    <BookOpen className="size-3.5 text-primary" />
                    <span>Panduan PM</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setTab("builder")}
                  className="inline-flex items-center gap-2 rounded-lg bg-ink px-4 py-2.5 text-xs font-semibold text-ink-foreground transition-colors hover:bg-primary whitespace-nowrap shrink-0 cursor-pointer"
                >
                  <Plus className="size-4 text-saffron" />
                  <span>Buat Modul Baru</span>
                </button>
              </div>
            </div>

            {/* Filter & Search Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-border bg-card p-3.5">
              <div className="relative min-w-[240px] flex-1">
                <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
                <input
                  type="search"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Cari judul modul, mata pelajaran, atau topik..."
                  className="h-9 w-full rounded-lg border border-border bg-canvas pr-3 pl-9 text-sm text-ink outline-none focus:border-primary"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1 rounded-lg bg-slate-100 p-1">
                {(["Semua", "SD/MI", "SMP/MTs", "SMA/MA", "SMK/MAK"] as const).map((j) => (
                  <button
                    key={j}
                    type="button"
                    onClick={() => setJenjangFilter(j)}
                    className={`rounded-md px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      jenjangFilter === j
                        ? "bg-card text-ink shadow-xs"
                        : "text-muted-foreground hover:text-ink"
                    }`}
                  >
                    {j}
                  </button>
                ))}
              </div>
            </div>

            {/* List Content */}
            {error && (
              <div className="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-800">
                {error}
              </div>
            )}

            {loading ? (
              <div className="grid gap-4 md:grid-cols-2">
                {[1, 2].map((i) => (
                  <div key={i} className="h-44 animate-pulse rounded-xl border border-border bg-card p-6" />
                ))}
              </div>
            ) : filteredModules.length === 0 ? (
              <div className="rounded-xl border border-border bg-card px-6 py-12 text-center">
                <FileText className="mx-auto size-8 text-muted-foreground" />
                <h2 className="mt-3 font-display text-lg font-semibold text-ink">
                  Belum ada modul yang cocok
                </h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Ubah kata kunci pencarian atau susun Modul Ajar & LKPD baru sesuai kelas Anda.
                </p>
                <button
                  type="button"
                  onClick={() => setTab("builder")}
                  className="mt-5 inline-flex items-center gap-2 rounded-lg bg-ink px-4 py-2 text-xs font-semibold text-ink-foreground transition-colors hover:bg-primary cursor-pointer"
                >
                  <Plus className="size-4 text-saffron" />
                  <span>Susun Modul Pertama</span>
                </button>
              </div>
            ) : (
              <div className="grid gap-4 md:grid-cols-2">
                {filteredModules.map((modul) => {
                  const canDelete = isAdmin || modul.ownerId === user.id;
                  return (
                    <article
                      key={modul.id}
                      className="flex flex-col justify-between rounded-xl border border-border bg-card p-6 transition-colors hover:border-slate-300"
                    >
                      <div>
                        <div className="text-xs font-medium text-muted-foreground tabular-nums">
                          {modul.identitas.jenjang} · {modul.identitas.fase} · {modul.identitas.kelas} ·{" "}
                          {modul.identitas.mataPelajaran} · {modul.identitas.alokasiWaktu} · 8 Lampiran
                        </div>
                        <h2 className="mt-2 font-display text-lg font-semibold leading-snug text-ink">
                          {modul.identitas.judulModul}
                        </h2>
                        <p className="mt-1.5 line-clamp-2 text-sm text-slate-600">
                          {modul.identitas.topik}
                        </p>
                      </div>

                      <div className="mt-5 flex items-center justify-between border-t border-border pt-4">
                        <span className="truncate text-xs text-muted-foreground">
                          {modul.identitas.modelPembelajaran}
                        </span>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => handleDuplicate(modul)}
                            title="Duplikat Modul"
                            aria-label="Duplikat Modul"
                            className="rounded-lg border border-border p-2 text-muted-foreground transition-colors hover:bg-slate-50 hover:text-ink cursor-pointer"
                          >
                            <Copy className="size-3.5" />
                          </button>
                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => handleDelete(modul.id)}
                              title="Hapus Modul"
                              aria-label="Hapus Modul"
                              className="rounded-lg border border-border p-2 text-muted-foreground transition-colors hover:border-red-200 hover:bg-red-50 hover:text-red-700 cursor-pointer"
                            >
                              <Trash2 className="size-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => setSelectedId(modul.id)}
                            className="rounded-lg bg-ink px-3.5 py-2 text-xs font-semibold text-ink-foreground transition-colors hover:bg-primary whitespace-nowrap cursor-pointer"
                          >
                            Buka Dokumen
                          </button>
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
